import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import GridList from '@material-ui/core/GridList';
import GridListTile from '@material-ui/core/GridListTile';
import GridListTileBar from '@material-ui/core/GridListTileBar';
import IconButton from '@material-ui/core/IconButton';
import StarBorderIcon from '@material-ui/icons/StarBorder';
import FriendCard from "./friendCard"
import tileData from './tileData';

const useStyles = makeStyles((theme) => ({
  root: {
    display: 'flex',
    flexWrap: 'wrap',
    justifyContent: 'space-around',
    overflow: 'hidden',
    backgroundColor: theme.palette.background.paper,
    float:"left",
  },
  gridList: {
    flexWrap: 'nowrap',
    height:335,
    // Promote the list into his own layer on Chrome. This cost memory but helps keeping high FPS.
    transform: 'translateZ(0)',
  },
  title: {
    color: theme.palette.primary.light,
  },
  titleBar: {
    background:
      'linear-gradient(to top, rgba(0,0,0,0.7) 0%, rgba(0,0,0,0.3) 70%, rgba(0,0,0,0) 100%)',
  },
}));

/**
 * The example data is structured as follows:
 *
 * import image from 'path/to/image.jpg';
 * [etc...]
 *
 * const tileData = [
 *   {
 *     img: image,
 *     title: 'Image',
 *     author: 'author',
 *   },
 *   {
 *     [etc...]
 *   },
 * ];
 */
export default function FriendList(props) {
  const classes = useStyles();
  console.log(props.data)
  let displaylength=props.data.length>8? 8:props.data.length

  return (
    <div>
      <br/>
    <div style={{textAlign:"left"}}><h5>Potential Study Partners:</h5></div>
    <br/>
    <div className={classes.root}>
      <GridList className={classes.gridList} cols={displaylength} spacing={1}>
        {props.data.map((tile,index) => (
          <GridListTile key={index} rows={13}>
            {/* <img src={tile.img} alt={tile.title} /> */}
            <FriendCard name={tile.name} num={tile.total} img={tile.img} class={tile.classes} contact={tile.contact}/>


          </GridListTile>
        ))}
      </GridList>
    </div>
    </div>
  );
}