export const ADD_Note = "ADD_Note";
export const Delete_Note = "Delete_Note"
