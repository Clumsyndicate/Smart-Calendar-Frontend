import './styles.css';

import React from 'react';
import ReactDOM from 'react-dom';

import App from './App.js';
// import demo from './demo.js'

ReactDOM.render(
  <App />,
  document.getElementById('app'),
 );
