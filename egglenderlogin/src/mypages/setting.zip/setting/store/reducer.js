import * as actionTypes from './types'
import isEmpty from 'lodash/isEmpty'
const initial = {
    settingRequest: false
}
export default (state = initial, action) => {
    return state;
};